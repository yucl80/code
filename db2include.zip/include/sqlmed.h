/**********************************************************************
*
*  Source File Name = sqlmed.h
*
*  (C) COPYRIGHT International Business Machines Corp. 2001, 2003
*  All Rights Reserved
*  Licensed Materials - Property of IBM
*
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*
*  Function = Include File defining:
*               Placeholder for SQL/MED support
*
*  Operating System = All
*
***********************************************************************/

#ifndef SQL_H_SQLMED
#define SQL_H_SQLMED

#endif /* SQL_H_SQLMED */
